import { create } from 'zustand';

// Mock data types
export interface GyroData {
    pitch: number;
    roll: number;
    yaw: number;
}

interface BLEState {
    isConnected: boolean;
    isScanning: boolean;
    batteryLevel: number;
    gyroData: GyroData;
    connect: () => Promise<void>;
    disconnect: () => void;
    startScanning: () => void;
}

// Simulation interval
let simulationInterval: NodeJS.Timeout | null = null;

export const useBLEStore = create<BLEState>((set, get) => ({
    isConnected: false,
    isScanning: false,
    batteryLevel: 100,
    gyroData: { pitch: 0, roll: 0, yaw: 0 },

    startScanning: () => {
        set({ isScanning: true });
        // Simulate finding device after 2 seconds
        setTimeout(() => {
            set({ isScanning: false });
            get().connect();
        }, 2000);
    },

    connect: async () => {
        // Simulate connection
        set({ isConnected: true });

        // Start simulating sensor data
        if (simulationInterval) clearInterval(simulationInterval);

        let time = 0;
        simulationInterval = setInterval(() => {
            time += 0.1;

            // Simulate normal head movement with occasional "nodding off" (pitch dropping)
            // Every 10 seconds, simulate a drowsiness event (pitch drops significantly)
            const isDrowsyEvent = Math.floor(time) % 20 >= 15; // 5 seconds of drowsiness every 20s

            const basePitch = isDrowsyEvent ? -45 : -10; // -10 is looking slightly down/straight, -45 is nodding off
            const noise = Math.random() * 5 - 2.5;

            set({
                gyroData: {
                    pitch: basePitch + noise,
                    roll: Math.random() * 2 - 1,
                    yaw: Math.random() * 2 - 1,
                },
                batteryLevel: Math.max(0, 100 - (time / 60)), // Drain battery slowly
            });
        }, 100);
    },

    disconnect: () => {
        if (simulationInterval) clearInterval(simulationInterval);
        set({ isConnected: false, gyroData: { pitch: 0, roll: 0, yaw: 0 } });
    },
}));
