import { create } from 'zustand';
import * as Speech from 'expo-speech';
import AsyncStorage from '@react-native-async-storage/async-storage';

type VoiceMode = 'challenge' | 'companion' | 'off';

interface VoiceCompanionState {
    isEnabled: boolean;
    mode: VoiceMode;
    intervalMinutes: number;
    lastInteractionTime: number;
    isSpeaking: boolean;
    userName: string;

    // Actions
    setEnabled: (enabled: boolean) => void;
    setMode: (mode: VoiceMode) => void;
    setIntervalMinutes: (minutes: number) => void;
    setUserName: (name: string) => void;
    startSession: () => void;
    stopSession: () => void;
    triggerInteraction: () => void;
    triggerOnDemand: () => void;
}

const MESSAGES = {
    companion: [
        "Olá {name}! Como está a ir a viagem?",
        "Estás a sentir-te cansado, {name}?",
        "Já consideraste fazer uma pausa?",
        "Mantém-te atento à estrada, {name}!",
        "Lembra-te de piscar os olhos regularmente.",
        "Que tal fazer uma pausa para café em breve?",
        "Estou aqui contigo, {name}. Vamos chegar em segurança.",
        "A tua segurança é o mais importante para mim, {name}.",
        "Respira fundo. Estamos juntos nesta viagem."
    ],
    challenge: [
        "Desafio rápido: Qual é a capital de França?",
        "Quanto é 7 vezes 8?",
        "Diz o nome de 3 cores em voz alta!",
        "Canta o refrão da tua música favorita!",
        "Olha para o espelho retrovisor e sorri!",
        "Qual foi a última vez que bebeste água?"
    ]
};

let interactionTimer: NodeJS.Timeout | null = null;

export const useVoiceCompanionStore = create<VoiceCompanionState>((set, get) => ({
    isEnabled: false,
    mode: 'companion',
    intervalMinutes: 30,
    lastInteractionTime: Date.now(),
    isSpeaking: false,
    userName: '',

    setUserName: async (name) => {
        set({ userName: name });
        await AsyncStorage.setItem('voice_username', name);
    },

    setEnabled: async (enabled) => {
        set({ isEnabled: enabled });
        if (enabled) {
            get().startSession();
        } else {
            get().stopSession();
        }
        await AsyncStorage.setItem('voice_enabled', JSON.stringify(enabled));
    },

    setMode: async (mode) => {
        set({ mode });
        await AsyncStorage.setItem('voice_mode', mode);
    },

    setIntervalMinutes: async (minutes) => {
        set({ intervalMinutes: minutes });
        await AsyncStorage.setItem('voice_interval', JSON.stringify(minutes));
        if (get().isEnabled) {
            get().stopSession();
            get().startSession();
        }
    },

    startSession: () => {
        const { isEnabled, intervalMinutes } = get();
        if (!isEnabled) return;

        console.log('🎤 Voice Companion Session Started');

        if (interactionTimer) clearInterval(interactionTimer);

        interactionTimer = setInterval(() => {
            get().triggerInteraction();
        }, intervalMinutes * 60 * 1000);
    },

    stopSession: () => {
        if (interactionTimer) {
            clearInterval(interactionTimer);
            interactionTimer = null;
        }
        Speech.stop();
        set({ isSpeaking: false });
        console.log('🎤 Voice Companion Session Stopped');
    },

    triggerInteraction: () => {
        const { isSpeaking, mode, userName } = get();

        if (isSpeaking) return;

        set({ lastInteractionTime: Date.now(), isSpeaking: true });

        const messageList = (mode !== 'off' && MESSAGES[mode]) ? MESSAGES[mode] : MESSAGES.companion;
        const randomMessage = messageList[Math.floor(Math.random() * messageList.length)];

        // Personalize message
        const personalizedMessage = randomMessage.replace(/{name}/g, userName || (mode === 'companion' ? 'querido' : 'condutor'));

        console.log(`🗣️ Speaking: ${personalizedMessage}`);

        Speech.speak(personalizedMessage, {
            language: 'pt-PT',
            onDone: () => {
                set({ isSpeaking: false });
            },
            onError: () => {
                set({ isSpeaking: false });
            }
        });
    },

    triggerOnDemand: () => {
        const { userName } = get();
        const onDemandMessages = [
            "Estou aqui, {name}. Precisas de alguma coisa?",
            "Olá {name}! Ainda bem que chamaste. Como te sentes?",
            "Estou atenta. Continua focado na estrada.",
            "Diz-me, {name}. Estás muito cansado?",
            "Vamos conversar para passar o tempo. Qual é o teu destino?"
        ];

        const randomMessage = onDemandMessages[Math.floor(Math.random() * onDemandMessages.length)];
        const personalizedMessage = randomMessage.replace(/{name}/g, userName || 'querido');

        console.log(`🗣️ On-Demand Speaking: ${personalizedMessage}`);

        Speech.speak(personalizedMessage, {
            language: 'pt-PT',
            onDone: () => {
                // Here we could start listening if we had STT
            }
        });
    }
}));

// Initialize
const init = async () => {
    try {
        const enabled = await AsyncStorage.getItem('voice_enabled');
        const mode = await AsyncStorage.getItem('voice_mode');
        const interval = await AsyncStorage.getItem('voice_interval');
        const username = await AsyncStorage.getItem('voice_username');

        if (enabled) useVoiceCompanionStore.setState({ isEnabled: JSON.parse(enabled) });
        if (mode) useVoiceCompanionStore.setState({ mode: mode as VoiceMode });
        if (interval) useVoiceCompanionStore.setState({ intervalMinutes: JSON.parse(interval) });
        if (username) useVoiceCompanionStore.setState({ userName: username });

        if (enabled && JSON.parse(enabled)) {
            useVoiceCompanionStore.getState().startSession();
        }
    } catch (e) {
        console.log('Error loading voice settings:', e);
    }
};

init();
