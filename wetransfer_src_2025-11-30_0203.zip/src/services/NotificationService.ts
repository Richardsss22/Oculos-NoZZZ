import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';

// Configure notifications to show even when app is in foreground
Notifications.setNotificationHandler({
    handleNotification: async () => ({
        shouldShowAlert: true,
        shouldPlaySound: true,
        shouldSetBadge: false,
    }),
});

export const setupNotifications = async () => {
    if (Platform.OS === 'android') {
        await Notifications.setNotificationChannelAsync('critical-alert', {
            name: 'Critical Alert',
            importance: Notifications.AndroidImportance.MAX,
            vibrationPattern: [0, 250, 250, 250],
            lightColor: '#FF231F7C',
        });
    }

    const { status } = await Notifications.requestPermissionsAsync();
    if (status !== 'granted') {
        console.log('❌ Notification permissions not granted!');
    }
};

export const sendEmergencyNotification = async () => {
    console.log('⌚ Sending Smartwatch Notification...');
    await Notifications.scheduleNotificationAsync({
        content: {
            title: '🚨 ALERTA DE SONOLÊNCIA! 🚨',
            body: 'ACORDA! Deteção de fadiga crítica!',
            data: { type: 'emergency' },
            sound: true,
            priority: Notifications.AndroidNotificationPriority.MAX,
            vibrate: [0, 500, 500, 500], // Aggressive vibration
        },
        trigger: null, // Send immediately
    });
};
