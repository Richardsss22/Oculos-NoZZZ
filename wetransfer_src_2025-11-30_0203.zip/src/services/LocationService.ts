import * as Location from 'expo-location';
import { create } from 'zustand';

interface LocationState {
    isDriving: boolean;
    speed: number; // km/h
    location: Location.LocationObject | null;
    startTracking: () => Promise<void>;
    stopTracking: () => void;
    toggleDrivingModeManual: () => void; // For testing
}

let locationSubscription: Location.LocationSubscription | null = null;

export const useLocationStore = create<LocationState>((set, get) => ({
    isDriving: false,
    speed: 0,
    location: null,

    startTracking: async () => {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== 'granted') {
            console.warn('Permission to access location was denied');
            return;
        }

        locationSubscription = await Location.watchPositionAsync(
            {
                accuracy: Location.Accuracy.High,
                timeInterval: 1000,
                distanceInterval: 10,
            },
            (location) => {
                const speedKmh = (location.coords.speed || 0) * 3.6;
                // Simple heuristic: if speed > 15km/h, assume driving
                // In real app, would need more robust logic (activity recognition)
                const isDriving = speedKmh > 15;

                set((state) => ({
                    location,
                    speed: speedKmh,
                    // Only auto-update isDriving if not manually overridden (logic could be complex, keeping simple for now)
                    // For this prototype, let's just update it based on speed OR manual toggle
                    isDriving: isDriving || state.isDriving,
                }));
            }
        );
    },

    stopTracking: () => {
        if (locationSubscription) {
            locationSubscription.remove();
            locationSubscription = null;
        }
    },

    toggleDrivingModeManual: () => {
        set((state) => ({ isDriving: !state.isDriving }));
    },
}));
