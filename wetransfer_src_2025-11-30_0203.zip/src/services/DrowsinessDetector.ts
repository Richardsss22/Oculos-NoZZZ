
import { create } from 'zustand';
import { useBLEStore } from './BLEService';
import { useLocationStore } from './LocationService';
import { Vibration } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import VolumeManager from 'react-native-volume-manager';
import RNImmediatePhoneCall from 'react-native-immediate-phone-call';
import VolumeModule from '../native/VolumeModule';
import { useCoffeeRadarStore } from './CoffeeRadarService';
import { sendEmergencyNotification } from './NotificationService';
import { useSettingsStore } from './SettingsStore';

export type FatigueLevel = 'none' | 'low' | 'medium' | 'high' | 'critical';

interface DrowsinessState {
    isDrowsy: boolean;
    drowsinessLevel: number;
    fatigueLevel: FatigueLevel;
    history: { timestamp: number; level: number; fatigueLevel: FatigueLevel }[];
    emergencyContact: string;
    countdown: number;
    setEmergencyContact: (contact: string) => Promise<void>;
    loadEmergencyContact: () => Promise<void>;
    checkDrowsiness: (pitch: number) => void;
    resetAlert: () => void;
    triggerAlert: () => Promise<void>;
}

const AUTO_CALL_DELAY_SEC = 30;

const FATIGUE_THRESHOLDS = {
    LOW: { pitch: -15, time: 500, eyesClosed: 2000 },
    MEDIUM: { pitch: -20, time: 1000, eyesClosed: 3000 },
    HIGH: { pitch: -25, time: 1500, eyesClosed: 5000 },
    CRITICAL: { pitch: -30, time: 2000, eyesClosed: 7000 },
};

let drowsyStartTime: number | null = null;
let countdownInterval: NodeJS.Timeout | null = null;
let originalVolume: number | null = null;

export const useDrowsinessStore = create<DrowsinessState>((set, get) => ({
    isDrowsy: false,
    drowsinessLevel: 0,
    fatigueLevel: 'none',
    history: [],
    emergencyContact: '112',
    countdown: AUTO_CALL_DELAY_SEC,

    setEmergencyContact: async (contact: string) => {
        set({ emergencyContact: contact });
        await AsyncStorage.setItem('emergencyContact', contact);
    },

    loadEmergencyContact: async () => {
        const saved = await AsyncStorage.getItem('emergencyContact');
        if (saved) {
            set({ emergencyContact: saved });
        }
        const savedHistory = await AsyncStorage.getItem('drowsinessHistory');
        if (savedHistory) {
            try {
                set({ history: JSON.parse(savedHistory) });
            } catch (e) {
                console.log('Error loading history:', e);
            }
        }
    },

    checkDrowsiness: (pitch: number) => {
        const { isDriving } = useLocationStore.getState();
        const { isDrowsy, fatigueLevel: currentFatigueLevel } = get();

        if (!isDriving) {
            drowsyStartTime = null;
            if (currentFatigueLevel !== 'none') {
                set({ fatigueLevel: 'none', drowsinessLevel: 0 });
            }
            return;
        }

        let eyesClosedDuration = 0;
        try {
            const { useEyeDetectionStore } = require('./EyeDetectionService');
            const eyeState = useEyeDetectionStore.getState();
            eyesClosedDuration = eyeState.eyesClosedDuration || 0;
        } catch (e) { }

        let detectedLevel: FatigueLevel = 'none';
        let shouldTrack = false;

        if (pitch < FATIGUE_THRESHOLDS.CRITICAL.pitch || eyesClosedDuration > FATIGUE_THRESHOLDS.CRITICAL.eyesClosed) {
            detectedLevel = 'critical';
            shouldTrack = true;
        } else if (pitch < FATIGUE_THRESHOLDS.HIGH.pitch || eyesClosedDuration > FATIGUE_THRESHOLDS.HIGH.eyesClosed) {
            detectedLevel = 'high';
            shouldTrack = true;
        } else if (pitch < FATIGUE_THRESHOLDS.MEDIUM.pitch || eyesClosedDuration > FATIGUE_THRESHOLDS.MEDIUM.eyesClosed) {
            detectedLevel = 'medium';
            shouldTrack = true;
        } else if (pitch < FATIGUE_THRESHOLDS.LOW.pitch || eyesClosedDuration > FATIGUE_THRESHOLDS.LOW.eyesClosed) {
            detectedLevel = 'low';
            shouldTrack = true;
        }

        if (shouldTrack) {
            if (!drowsyStartTime) {
                drowsyStartTime = Date.now();
                console.log(`Fatigue timer started for level: ${detectedLevel}`);
            } else {
                const duration = Date.now() - drowsyStartTime;
                const threshold = FATIGUE_THRESHOLDS[
                    detectedLevel.toUpperCase() as keyof typeof FATIGUE_THRESHOLDS
                ].time;

                if (duration > threshold) {
                    if (currentFatigueLevel !== detectedLevel) {
                        console.log(`✅ Fatigue level changed: ${currentFatigueLevel} -> ${detectedLevel}`);
                        set({ fatigueLevel: detectedLevel });

                        if (detectedLevel === 'medium' && !isDrowsy) {
                            console.log('☕ Triggering Coffee Radar...');
                            useCoffeeRadarStore.getState().searchNearbyPlaces();
                        }

                        if ((detectedLevel === 'critical' || detectedLevel === 'high') && !isDrowsy) {
                            console.log('⚠️ TRIGGERING CRITICAL ALERT!');
                            get().triggerAlert();
                        }
                    }
                }
            }
        } else {
            drowsyStartTime = null;
            if (currentFatigueLevel !== 'none' && !isDrowsy) {
                set({ fatigueLevel: 'none', drowsinessLevel: 0 });
            }
        }
    },

    triggerAlert: async () => {
        const { isDrowsy } = get();
        if (isDrowsy) return;

        console.log('🚨 ALERT TRIGGERED!');

        // 1. Force Volume
        try {
            console.log('🔊 FORCING MAXIMUM VOLUME...');
            await VolumeModule.setMaxVolume();
            console.log('📢 VOLUME AT MAXIMUM!');
        } catch (error) {
            console.log('❌ Volume failed:', error);
        }

        const newHistory = [...get().history, { timestamp: Date.now(), level: 100, fatigueLevel: 'critical' as FatigueLevel }];

        set({
            isDrowsy: true,
            drowsinessLevel: 100,
            fatigueLevel: 'critical',
            history: newHistory,
            countdown: AUTO_CALL_DELAY_SEC,
        });

        AsyncStorage.setItem('drowsinessHistory', JSON.stringify(newHistory));

        // 2. Play Native Alarm & Strobe (Moved to UI for Camera Sync)
        // The UI (DashboardScreen) listens to isDrowsy and triggers these
        // to ensure the Camera is unmounted first.

        // 4. Smartwatch Notification
        try {
            const { smartwatchEnabled } = useSettingsStore.getState().settings;
            if (smartwatchEnabled) {
                await sendEmergencyNotification();
            }
        } catch (error) {
            console.log('❌ Error sending notification:', error);
        }

        // 5. Vibration
        Vibration.vibrate([1000, 500], true);

        // 5. Countdown
        if (countdownInterval) clearInterval(countdownInterval);

        countdownInterval = setInterval(() => {
            const { countdown, emergencyContact } = get();

            if (countdown <= 1) {
                if (countdownInterval) clearInterval(countdownInterval);
                set({ countdown: 0 });
                console.log('📞 Calling emergency:', emergencyContact);
                RNImmediatePhoneCall.immediatePhoneCall(emergencyContact);
            } else {
                set({ countdown: countdown - 1 });
            }
        }, 1000);
    },

    resetAlert: async () => {
        console.log('Resetting alert...');

        if (originalVolume !== null) {
            try {
                await VolumeManager.setVolume(originalVolume);
                console.log('📢 Volume restored');
            } catch (error) {
                console.log('❌ Failed to restore volume');
            }
            originalVolume = null;
        }

        // Stop Native Alarm & Strobe (Handled by UI useEffect)
        // But we can double check here just in case
        try {
            await VolumeModule.stopAlarm();
            await VolumeModule.stopStrobe();
        } catch (e) {
            console.log('Error stopping alarm/strobe:', e);
        }

        Vibration.cancel();
        if (countdownInterval) clearInterval(countdownInterval);

        set({ isDrowsy: false, drowsinessLevel: 0, countdown: AUTO_CALL_DELAY_SEC });
        drowsyStartTime = null;
        console.log('✅ Alert reset complete');
    },
}));

useDrowsinessStore.getState().loadEmergencyContact();

useBLEStore.subscribe((state) => {
    useDrowsinessStore.getState().checkDrowsiness(state.gyroData.pitch);
});
