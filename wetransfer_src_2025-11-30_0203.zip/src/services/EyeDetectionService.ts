import { create } from 'zustand';
import { useDrowsinessStore } from './DrowsinessDetector';
import { useCustomSettingsStore } from './CustomSettingsStore';

interface EyeDetectionState {
    isCameraActive: boolean;
    eyesClosedDuration: number; // milliseconds
    blinkCount: number;
    lastBlinkTime: number;
    isEyesClosed: boolean;
    leftEyeOpen: number;
    rightEyeOpen: number;
    startCamera: () => void;
    stopCamera: () => void;
    updateFaceData: (faces: any[]) => void;
}

const DEFAULT_EYES_CLOSED_THRESHOLD = 0.4; // Slightly higher threshold for better sensitivity
const DEFAULT_ALARM_DURATION_MS = 5000; // 5 seconds default
const BLINK_DURATION_MAX = 500; // ms
const BLINK_DURATION_MIN = 50; // ms

let eyesClosedStartTime: number | null = null;

export const useEyeDetectionStore = create<EyeDetectionState>((set, get) => ({
    isCameraActive: false,
    eyesClosedDuration: 0,
    blinkCount: 0,
    lastBlinkTime: 0,
    isEyesClosed: false,
    leftEyeOpen: 1.0,
    rightEyeOpen: 1.0,

    startCamera: () => {
        set({ isCameraActive: true });
        console.log('📸 Vision Camera started');
    },

    stopCamera: () => {
        set({
            isCameraActive: false,
            eyesClosedDuration: 0,
            isEyesClosed: false,
            leftEyeOpen: 1.0,
            rightEyeOpen: 1.0
        });
        eyesClosedStartTime = null;
        console.log('📸 Vision Camera stopped');
    },

    updateFaceData: (faces: any[]) => {
        if (!faces || faces.length === 0) {
            // No face detected - reset or keep last state? Resetting is safer to avoid false alarms
            eyesClosedStartTime = null;
            set({ isEyesClosed: false, eyesClosedDuration: 0 });
            return;
        }

        const face = faces[0]; // Use first detected face

        // ML Kit via Vision Camera returns these props. 
        // For front camera (mirrored), we swap them to match user's perspective (My Right Eye = Screen Right)
        const leftEyeOpen = face.rightEyeOpenProbability !== undefined ? face.rightEyeOpenProbability : 1.0;
        const rightEyeOpen = face.leftEyeOpenProbability !== undefined ? face.leftEyeOpenProbability : 1.0;

        // Get custom settings if enabled
        const customSettings = useCustomSettingsStore.getState();
        const eyeClosedThreshold = customSettings.isCustomMode
            ? customSettings.settings.eyeOpenThreshold
            : DEFAULT_EYES_CLOSED_THRESHOLD;
        const alarmDurationMs = customSettings.isCustomMode
            ? customSettings.settings.eyeClosureDuration * 1000
            : DEFAULT_ALARM_DURATION_MS;

        const averageEyeOpen = (leftEyeOpen + rightEyeOpen) / 2;
        const eyesClosed = averageEyeOpen < eyeClosedThreshold;

        set({ leftEyeOpen, rightEyeOpen });

        // console.log(`👁️ Eyes: L=${leftEyeOpen.toFixed(2)} R=${rightEyeOpen.toFixed(2)}`);

        if (eyesClosed) {
            if (!eyesClosedStartTime) {
                eyesClosedStartTime = Date.now();
                set({ isEyesClosed: true });
                // console.log('⚠️ Eyes closed - timer started');
            } else {
                const duration = Date.now() - eyesClosedStartTime;
                set({ eyesClosedDuration: duration });

                // console.log(`⏱️ Eyes closed for ${(duration / 1000).toFixed(1)}s`);

                // If eyes have been closed for configured duration, trigger the main alarm
                if (duration > alarmDurationMs) {
                    console.log(`🚨 EYES CLOSED > ${alarmDurationMs / 1000} SECONDS! TRIGGERING ALARM`);
                    // Trigger the main alarm in DrowsinessDetector
                    useDrowsinessStore.getState().triggerAlert();
                }
            }
        } else {
            // Eyes opened
            if (eyesClosedStartTime && get().isEyesClosed) {
                const closedDuration = Date.now() - eyesClosedStartTime;

                // Detect blink (short eye closure)
                if (closedDuration < BLINK_DURATION_MAX && closedDuration > BLINK_DURATION_MIN) {
                    const { lastBlinkTime, blinkCount } = get();
                    const timeSinceLastBlink = Date.now() - lastBlinkTime;

                    if (timeSinceLastBlink > 500) {
                        const newBlinkCount = blinkCount + 1;
                        set({
                            blinkCount: newBlinkCount,
                            lastBlinkTime: Date.now()
                        });
                        console.log(`👁️ BLINK detected! Total: ${newBlinkCount}`);
                    }
                }
            }

            eyesClosedStartTime = null;
            set({ isEyesClosed: false, eyesClosedDuration: 0 });
        }
    },
}));
