declare module 'react-native-immediate-phone-call' {
    function immediatePhoneCall(phoneNumber: string): void;
    export default {
        immediatePhoneCall
    };
}
