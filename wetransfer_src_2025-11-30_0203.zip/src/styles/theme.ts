import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface ThemeState {
    isDarkMode: boolean;
    toggleTheme: () => Promise<void>;
    loadTheme: () => Promise<void>;
}

export const useThemeStore = create<ThemeState>((set, get) => ({
    isDarkMode: false, // Default LIGHT mode

    toggleTheme: async () => {
        const newMode = !get().isDarkMode;
        set({ isDarkMode: newMode });
        await AsyncStorage.setItem('theme', newMode ? 'dark' : 'light');
    },

    loadTheme: async () => {
        const saved = await AsyncStorage.getItem('theme');
        if (saved) {
            set({ isDarkMode: saved === 'dark' });
        } else {
            // First time - default to light
            set({ isDarkMode: false });
        }
    },
}));

export const getTheme = (isDark: boolean) => isDark ? darkTheme : lightTheme;

const lightTheme = {
    background: '#F5F5F5',
    card: '#FFFFFF',
    text: '#000000',
    textSecondary: '#666666',
    border: '#E0E0E0',
    primary: '#2196F3',
    danger: '#FF3B30',
    success: '#4CAF50',
    inputBg: '#F0F0F0',
    inactive: '#999999',
};

const darkTheme = {
    background: '#121212',
    card: '#1E1E1E',
    text: '#FFFFFF',
    textSecondary: '#AAAAAA',
    border: '#333',
    primary: '#2196F3',
    danger: '#FF3B30',
    success: '#4CAF50',
    inputBg: '#2C2C2C',
    inactive: '#666',
};
