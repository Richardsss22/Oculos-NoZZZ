import React, { useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { useBLEStore } from '../services/BLEService';
import { useLocationStore } from '../services/LocationService';
import { useDrowsinessStore } from '../services/DrowsinessDetector';
import { useThemeStore, getTheme } from '../styles/theme';
import { useI18nStore } from '../i18n/i18nStore';
import { SafeAreaView } from 'react-native-safe-area-context';
import CameraViewComponent from '../components/CameraView';
import { useCoffeeRadarStore } from '../services/CoffeeRadarService';
import type { FatigueLevel } from '../services/DrowsinessDetector';
import AsyncStorage from '@react-native-async-storage/async-storage';

import { PermissionService } from '../services/PermissionService';
import VolumeModule from '../native/VolumeModule';
import { useVoiceCompanionStore } from '../services/VoiceCompanionService';
import { sendEmergencyNotification } from '../services/NotificationService';

export default function DashboardScreen({ navigation }: any) {
    const { isConnected, isScanning, startScanning, disconnect, gyroData, batteryLevel } = useBLEStore();
    const { isDriving, speed, startTracking, stopTracking, toggleDrivingModeManual } = useLocationStore();
    const { isDrowsy, resetAlert, countdown } = useDrowsinessStore();
    const { nearbyPlaces, isSearching, dismissSuggestion, navigateToPlace, error } = useCoffeeRadarStore();
    const { isDarkMode } = useThemeStore();
    const { t, language } = useI18nStore();
    const { triggerOnDemand, isEnabled: isVoiceEnabled } = useVoiceCompanionStore();
    const colors = getTheme(isDarkMode);



    useEffect(() => {
        const init = async () => {
            await PermissionService.requestAllPermissions();
            startTracking();
        };
        init();
        return () => stopTracking();
    }, []);

    // --- ALARM & STROBE LOGIC (UI LAYER) ---
    // We handle this here to ensure the Camera is unmounted BEFORE the flashlight starts.
    useEffect(() => {
        let timeout: NodeJS.Timeout;

        const triggerAlarm = async () => {
            if (isDrowsy) {
                // 1. Camera is unmounted automatically because of conditional rendering below
                console.log('🚨 UI: Drowsiness detected. Waiting for camera to unmount...');

                // 2. Wait for hardware release
                timeout = setTimeout(async () => {
                    console.log('🚨 UI: Triggering Native Alarm & Strobe...');

                    // Play Alarm
                    try {
                        await VolumeModule.playAlarm();
                    } catch (e) { console.error('Alarm error:', e); }

                    // Start Strobe (if enabled)
                    try {
                        const strobeEnabled = await AsyncStorage.getItem('strobe_enabled');
                        if (strobeEnabled === null || strobeEnabled === 'true') {
                            await VolumeModule.strobeFlashlight();
                        }
                    } catch (e) { console.error('Strobe error:', e); }

                    // Trigger Smartwatch Notification (High Priority)
                    try {
                        await sendEmergencyNotification();
                    } catch (e) { console.error('Notification error:', e); }

                }, 250); // 250ms delay to be safe
            } else {
                // Stop everything
                try {
                    await VolumeModule.stopAlarm();
                    await VolumeModule.stopStrobe();
                } catch (e) { }
            }
        };

        triggerAlarm();

        return () => {
            if (timeout) clearTimeout(timeout);
        };
    }, [isDrowsy]);

    return (
        <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
            <ScrollView contentContainerStyle={styles.scrollContent}>
                <View style={styles.header}>
                    <Text style={[styles.title, { color: colors.text }]}>{t('appName')} <Text style={{ fontSize: 12, color: 'red' }}>v2.0 (Flashlight)</Text></Text>
                    <TouchableOpacity onPress={() => navigation.navigate('Settings')}>
                        <Text style={styles.icon}>⚙️</Text>
                    </TouchableOpacity>
                </View>

                {/* Camera Eye Detection - UNMOUNT ON ALERT */}
                {!isDrowsy && <CameraViewComponent />}

                {/* Placeholder when camera is hidden (optional, keeps layout stable) */}
                {isDrowsy && (
                    <View style={[styles.card, { height: 200, justifyContent: 'center', alignItems: 'center', backgroundColor: '#000' }]}>
                        <Text style={{ fontSize: 40 }}>🚨</Text>
                        <Text style={{ color: '#FFF', marginTop: 10 }}>ALARM ACTIVE</Text>
                    </View>
                )}

                {/* Status Cards */}
                <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
                    <Text style={[styles.cardTitle, { color: colors.textSecondary }]}>{t('glassesStatus')}</Text>
                    <View style={styles.row}>
                        <Text style={[styles.statusText, isConnected ? styles.connected : styles.disconnected]}>
                            {isConnected ? t('connected') : isScanning ? t('searching') : t('disconnected')}
                        </Text>
                        {isConnected && <Text style={styles.batteryText}>🔋 {Math.round(batteryLevel)}%</Text>}
                    </View>
                    {!isConnected && (
                        <TouchableOpacity
                            style={styles.button}
                            onPress={isScanning ? undefined : startScanning}
                            disabled={isScanning}
                        >
                            <Text style={styles.buttonText}>{isScanning ? t('searching') : t('connectGlasses')}</Text>
                        </TouchableOpacity>
                    )}
                    {isConnected && (
                        <TouchableOpacity style={[styles.button, styles.buttonOutline]} onPress={disconnect}>
                            <Text style={[styles.buttonText, styles.textOutline]}>{t('disconnect')}</Text>
                        </TouchableOpacity>
                    )}
                </View>

                <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
                    <Text style={[styles.cardTitle, { color: colors.textSecondary }]}>{t('drivingMonitoring')}</Text>
                    <View style={styles.row}>
                        <View>
                            <Text style={[styles.label, { color: colors.inactive }]}>{t('speed')}</Text>
                            <Text style={[styles.value, { color: colors.text }]}>{Math.round(speed)} km/h</Text>
                        </View>
                        <View>
                            <Text style={[styles.label, { color: colors.inactive }]}>{t('status')}</Text>
                            <Text style={[styles.statusText, isDriving ? styles.driving : styles.idle]}>
                                {isDriving ? t('driving') : t('stopped')}
                            </Text>
                        </View>
                    </View>
                    <TouchableOpacity style={[styles.smallButton, { backgroundColor: colors.inputBg }]} onPress={toggleDrivingModeManual}>
                        <Text style={[styles.smallButtonText, { color: colors.textSecondary }]}>
                            {isDriving ? t('simulateStop') : t('simulateDriving')}
                        </Text>
                    </TouchableOpacity>
                </View>

                {/* Talk Now Button */}
                {isVoiceEnabled && (
                    <TouchableOpacity
                        style={[styles.button, { backgroundColor: '#9C27B0', marginBottom: 20 }]}
                        onPress={triggerOnDemand}
                    >
                        <Text style={styles.buttonText}>🗣️ {language === 'pt' ? 'Falar Agora' : 'Talk Now'}</Text>
                    </TouchableOpacity>
                )}

                {/* DEBUG: Test Alarm Button */}
                <TouchableOpacity
                    style={[styles.button, { backgroundColor: '#FF9800', marginBottom: 20 }]}
                    onPress={async () => {
                        try {
                            console.log('Testing Alarm...');
                            await VolumeModule.setMaxVolume();
                            await VolumeModule.playAlarm();
                            setTimeout(() => VolumeModule.stopAlarm(), 5000);
                        } catch (e) {
                            console.error('Alarm test failed', e);
                        }
                    }}
                >
                    <Text style={styles.buttonText}>🔊 TEST ALARM (5s)</Text>
                </TouchableOpacity>



                {/* Coffee Radar - Always Visible */}
                <View style={[styles.coffeeRadarCard, {
                    backgroundColor: nearbyPlaces.length > 0 ? '#FFF3CD' : colors.card,
                    borderColor: nearbyPlaces.length > 0 ? '#FFC107' : colors.border
                }]}>
                    <View style={styles.coffeeRadarHeader}>
                        <Text style={styles.coffeeRadarIcon}>☕</Text>
                        <View style={{ flex: 1 }}>
                            <Text style={[styles.coffeeRadarTitle, { color: nearbyPlaces.length > 0 ? '#856404' : colors.text }]}>
                                {t('coffeeRadar')}
                            </Text>
                            <Text style={[styles.coffeeRadarSubtitle, { color: nearbyPlaces.length > 0 ? '#856404' : colors.textSecondary }]}>
                                {nearbyPlaces.length > 0
                                    ? `${nearbyPlaces.length} ${language === 'pt' ? 'cafés encontrados' : 'cafes found'}`
                                    : (language === 'pt' ? 'Procurar cafés próximos' : 'Find nearby cafes')
                                }
                            </Text>
                        </View>
                        {!isSearching && (
                            <TouchableOpacity
                                style={[styles.refreshButton, { backgroundColor: colors.primary }]}
                                onPress={() => useCoffeeRadarStore.getState().searchNearbyPlaces()}
                            >
                                <Text style={{ fontSize: 20 }}>🔄</Text>
                            </TouchableOpacity>
                        )}
                    </View>

                    {isSearching && (
                        <Text style={[styles.searchingText, { color: colors.textSecondary }]}>
                            {t('searchingNearbyPlaces')}
                        </Text>
                    )}

                    {error && !isSearching && (
                        <Text style={[styles.errorText, { color: '#D32F2F' }]}>
                            ❌ {error === 'API key not configured' ? 'API key não configurada' :
                                error === 'Location not available' ? 'GPS não disponível. Ativa a localização.' :
                                    error === 'No places found' ? 'Nenhum café encontrado próximo.' :
                                        `Erro: ${error}`}
                        </Text>
                    )}

                    {nearbyPlaces.length > 0 && !isSearching && (
                        <>
                            <ScrollView
                                style={styles.placesScrollView}
                                nestedScrollEnabled={true}
                                showsVerticalScrollIndicator={true}
                            >
                                {nearbyPlaces.map((place, index) => (
                                    <View
                                        key={place.placeId}
                                        style={[
                                            styles.placeItem,
                                            { backgroundColor: index === 0 ? '#FFF9E6' : 'transparent', borderBottomColor: '#E0E0E0' }
                                        ]}
                                    >
                                        <View style={styles.placeInfo}>
                                            <View style={styles.placeHeader}>
                                                <Text style={styles.placeRank}>{index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : `${index + 1}.`}</Text>
                                                <View style={{ flex: 1 }}>
                                                    <Text style={styles.placeName}>{place.name}</Text>
                                                    {place.address && (
                                                        <Text style={styles.placeAddress} numberOfLines={1}>{place.address}</Text>
                                                    )}
                                                </View>
                                                <Text style={styles.placeDistance}>{place.distance}km</Text>
                                            </View>
                                        </View>
                                        <TouchableOpacity
                                            style={[styles.placeNavigateButton, { backgroundColor: colors.primary }]}
                                            onPress={() => navigateToPlace(place)}
                                        >
                                            <Text style={styles.placeNavigateText}>🗺️ {t('navigate')}</Text>
                                        </TouchableOpacity>
                                    </View>
                                ))}
                            </ScrollView>
                            <TouchableOpacity
                                style={[styles.dismissAllButton, { borderColor: colors.border }]}
                                onPress={dismissSuggestion}
                            >
                                <Text style={[styles.dismissAllText, { color: colors.textSecondary }]}>{t('dismiss')}</Text>
                            </TouchableOpacity>
                        </>
                    )}

                    {nearbyPlaces.length === 0 && !isSearching && (
                        <Text style={[styles.coffeeHint, { color: colors.inactive }]}>
                            {language === 'pt' ? '💡 Toca no botão para procurar cafés próximos' : '💡 Tap the button to find nearby cafes'}
                        </Text>
                    )}
                </View>

                {/* Sensor Data Visualization */}
                {isConnected && (
                    <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
                        <Text style={[styles.cardTitle, { color: colors.textSecondary }]}>{t('realtimeData')}</Text>
                        <View style={styles.sensorRow}>
                            <View style={styles.sensorItem}>
                                <Text style={[styles.sensorLabel, { color: colors.inactive }]}>{t('pitch')}</Text>
                                <Text style={[styles.sensorValue, { color: colors.text }]}>{gyroData.pitch.toFixed(1)}°</Text>
                            </View>
                            <View style={styles.sensorItem}>
                                <Text style={[styles.sensorLabel, { color: colors.inactive }]}>{t('roll')}</Text>
                                <Text style={[styles.sensorValue, { color: colors.text }]}>{gyroData.roll.toFixed(1)}°</Text>
                            </View>
                            <View style={styles.sensorItem}>
                                <Text style={[styles.sensorLabel, { color: colors.inactive }]}>{t('yaw')}</Text>
                                <Text style={[styles.sensorValue, { color: colors.text }]}>{gyroData.yaw.toFixed(1)}°</Text>
                            </View>
                        </View>
                    </View>
                )}

                {/* Alert Overlay */}
                {isDrowsy && (
                    <View style={styles.alertBox}>
                        <Text style={styles.alertTitle}>⚠️ {t('drowsinessAlert')} ⚠️</Text>
                        <Text style={styles.alertText}>{t('extremeFatigue')}</Text>

                        <Text style={styles.countdownText}>
                            {t('emergencyCallIn')}: {countdown}s
                        </Text>

                        <TouchableOpacity style={styles.resetButton} onPress={resetAlert}>
                            <Text style={styles.resetButtonText}>{t('imOk')}</Text>
                        </TouchableOpacity>
                    </View>
                )}

                <TouchableOpacity
                    style={styles.historyButton}
                    onPress={() => navigation.navigate('History')}
                >
                    <Text style={styles.historyButtonText}>{t('viewHistory')}</Text>
                </TouchableOpacity>

            </ScrollView>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    scrollContent: {
        padding: 20,
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 30,
    },
    title: {
        fontSize: 28,
        fontWeight: 'bold',
    },
    icon: {
        fontSize: 24,
    },
    card: {
        borderRadius: 16,
        padding: 20,
        marginBottom: 20,
        borderWidth: 1,
    },
    cardTitle: {
        fontSize: 18,
        fontWeight: '600',
        marginBottom: 15,
    },
    row: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 15,
    },
    statusText: {
        fontSize: 18,
        fontWeight: 'bold',
    },
    connected: { color: '#4CAF50' },
    disconnected: { color: '#F44336' },
    driving: { color: '#2196F3' },
    idle: { color: '#9E9E9E' },
    batteryText: {
        color: '#4CAF50',
        fontWeight: 'bold',
    },
    button: {
        backgroundColor: '#2196F3',
        padding: 15,
        borderRadius: 12,
        alignItems: 'center',
    },
    buttonOutline: {
        backgroundColor: 'transparent',
        borderWidth: 1,
        borderColor: '#F44336',
        marginTop: 10,
    },
    buttonText: {
        color: '#FFFFFF',
        fontWeight: 'bold',
        fontSize: 16,
    },
    textOutline: {
        color: '#F44336',
    },
    label: {
        fontSize: 14,
    },
    value: {
        fontSize: 20,
        fontWeight: 'bold',
    },
    smallButton: {
        padding: 10,
        borderRadius: 8,
        alignItems: 'center',
        marginTop: 10,
    },
    smallButtonText: {
        fontSize: 12,
    },
    sensorRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    sensorItem: {
        alignItems: 'center',
    },
    sensorLabel: {
        marginBottom: 5,
    },
    sensorValue: {
        fontWeight: 'bold',
        fontSize: 16,
    },
    alertBox: {
        backgroundColor: '#FF3B30',
        padding: 20,
        borderRadius: 16,
        marginBottom: 20,
        alignItems: 'center',
    },
    alertTitle: {
        color: '#FFF',
        fontSize: 22,
        fontWeight: 'bold',
        marginBottom: 10,
        textAlign: 'center',
    },
    alertText: {
        color: '#FFF',
        fontSize: 16,
        marginBottom: 10,
        textAlign: 'center',
    },
    countdownText: {
        color: '#FFF',
        fontSize: 18,
        fontWeight: 'bold',
        marginBottom: 20,
        textAlign: 'center',
        backgroundColor: 'rgba(0,0,0,0.2)',
        padding: 10,
        borderRadius: 8,
    },
    resetButton: {
        backgroundColor: '#FFF',
        paddingHorizontal: 30,
        paddingVertical: 12,
        borderRadius: 25,
    },
    resetButtonText: {
        color: '#FF3B30',
        fontWeight: 'bold',
        fontSize: 16,
    },
    historyButton: {
        alignItems: 'center',
        padding: 20,
    },
    historyButtonText: {
        color: '#2196F3',
        fontSize: 16,
    },

    // Coffee Radar Styles
    coffeeRadarCard: {
        borderRadius: 16,
        padding: 20,
        marginBottom: 20,
        borderWidth: 2,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        elevation: 3,
    },
    coffeeRadarHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 15,
        gap: 12,
    },
    coffeeRadarIcon: {
        fontSize: 36,
    },
    coffeeRadarTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        marginBottom: 4,
    },
    coffeeRadarSubtitle: {
        fontSize: 14,
    },
    refreshButton: {
        width: 44,
        height: 44,
        borderRadius: 22,
        justifyContent: 'center',
        alignItems: 'center',
    },
    searchingText: {
        fontSize: 14,
        fontStyle: 'italic',
        marginBottom: 10,
    },
    errorText: {
        fontSize: 14,
        fontWeight: '600',
        marginBottom: 10,
        textAlign: 'center',
    },
    coffeeRadarLocation: {
        marginBottom: 15,
        paddingVertical: 8,
        paddingHorizontal: 12,
        backgroundColor: 'rgba(255, 193, 7, 0.1)',
        borderRadius: 8,
    },
    locationAddress: {
        fontSize: 13,
        color: '#666',
    },
    coffeeRadarActions: {
        flexDirection: 'row',
        gap: 10,
    },
    coffeeButton: {
        flex: 1,
        paddingVertical: 12,
        paddingHorizontal: 15,
        borderRadius: 10,
        alignItems: 'center',
    },
    navigateButton: {
        backgroundColor: '#2196F3',
    },
    navigateButtonText: {
        color: '#FFFFFF',
        fontWeight: 'bold',
        fontSize: 15,
    },
    dismissButton: {
        backgroundColor: 'transparent',
        borderWidth: 1,
        borderColor: '#856404',
    },
    dismissButtonText: {
        color: '#856404',
        fontWeight: '600',
        fontSize: 15,
    },
    coffeeHint: {
        fontSize: 13,
        textAlign: 'center',
        fontStyle: 'italic',
    },
    placesScrollView: {
        maxHeight: 360, // ~4 items visible (each item ~90px)
    },
    placeItem: {
        paddingVertical: 12,
        paddingHorizontal: 8,
        borderBottomWidth: 1,
        marginBottom: 8,
    },
    placeInfo: {
        marginBottom: 8,
    },
    placeHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
    },
    placeRank: {
        fontSize: 20,
        fontWeight: 'bold',
        width: 30,
    },
    placeName: {
        fontSize: 15,
        fontWeight: '600',
        color: '#333',
        marginBottom: 2,
    },
    placeAddress: {
        fontSize: 12,
        color: '#666',
    },
    placeDistance: {
        fontSize: 14,
        fontWeight: 'bold',
        color: '#2196F3',
        minWidth: 50,
        textAlign: 'right',
    },
    placeNavigateButton: {
        paddingVertical: 8,
        paddingHorizontal: 12,
        borderRadius: 8,
        alignItems: 'center',
    },
    placeNavigateText: {
        color: '#FFFFFF',
        fontWeight: '600',
        fontSize: 14,
    },
    dismissAllButton: {
        paddingVertical: 12,
        borderRadius: 8,
        alignItems: 'center',
        marginTop: 10,
        borderWidth: 1,
    },
    dismissAllText: {
        fontWeight: '600',
        fontSize: 14,
    },
});
