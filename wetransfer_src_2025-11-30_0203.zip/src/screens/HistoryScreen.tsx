import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { useDrowsinessStore } from '../services/DrowsinessDetector';
import { useThemeStore, getTheme } from '../styles/theme';
import { useI18nStore } from '../i18n/i18nStore';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LineChart } from 'react-native-chart-kit';
import { Dimensions } from 'react-native';

export default function HistoryScreen() {
    const { history } = useDrowsinessStore();
    const { isDarkMode } = useThemeStore();
    const { t } = useI18nStore();
    const colors = getTheme(isDarkMode);

    // Prepare data for chart
    const last10Events = history.slice(-10);
    const chartData = {
        labels: last10Events.map((_, i) => `${i + 1}`),
        datasets: [{
            data: last10Events.length > 0 ? last10Events.map((e: any) => e.level) : [0],
        }],
    };

    return (
        <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
            <ScrollView contentContainerStyle={styles.scrollContent}>
                <Text style={[styles.title, { color: colors.text }]}>{t('history')}</Text>

                {history.length === 0 ? (
                    <View style={styles.emptyState}>
                        <Text style={styles.emptyIcon}>📊</Text>
                        <Text style={[styles.emptyText, { color: colors.text }]}>{t('noEvents')}</Text>
                        <Text style={[styles.emptySubtext, { color: colors.inactive }]}>
                            {t('eventsWillAppear')}
                        </Text>
                    </View>
                ) : (
                    <>
                        <View style={[styles.statsCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                            <Text style={[styles.statsTitle, { color: colors.text }]}>{t('statistics')}</Text>
                            <View style={styles.statsRow}>
                                <StatItem label={t('totalEvents')} value={history.length.toString()} colors={colors} />
                                <StatItem label={t('lastEvent')}
                                    value={new Date(history[history.length - 1].timestamp).toLocaleTimeString('pt-PT', {
                                        hour: '2-digit',
                                        minute: '2-digit'
                                    })}
                                    colors={colors}
                                />
                            </View>
                        </View>

                        <View style={[styles.chartCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                            <Text style={[styles.chartTitle, { color: colors.text }]}>{t('last10Events')}</Text>
                            <LineChart
                                data={chartData}
                                width={Dimensions.get('window').width - 60}
                                height={220}
                                chartConfig={{
                                    backgroundColor: colors.card,
                                    backgroundGradientFrom: colors.card,
                                    backgroundGradientTo: colors.card,
                                    decimalPlaces: 0,
                                    color: (opacity = 1) => `rgba(255, 59, 48, ${opacity})`,
                                    labelColor: (opacity = 1) => isDarkMode ? `rgba(255, 255, 255, ${opacity})` : `rgba(0, 0, 0, ${opacity})`,
                                    style: { borderRadius: 16 },
                                    propsForDots: { r: '6', strokeWidth: '2', stroke: '#FF3B30' },
                                }}
                                bezier
                                style={styles.chart}
                            />
                        </View>

                        <Text style={[styles.listTitle, { color: colors.text }]}>{t('recentEvents')}</Text>
                        {history.slice().reverse().map((event: any, index: number) => (
                            <EventCard key={index} event={event} colors={colors} />
                        ))}
                    </>
                )}
            </ScrollView>
        </SafeAreaView>
    );
}

function StatItem({ label, value, colors }: { label: string; value: string; colors: any }) {
    return (
        <View style={styles.statItem}>
            <Text style={styles.statValue}>{value}</Text>
            <Text style={[styles.statLabel, { color: colors.inactive }]}>{label}</Text>
        </View>
    );
}

function EventCard({ event, colors }: { event: { timestamp: number; level: number }; colors: any }) {
    const date = new Date(event.timestamp);
    const timeStr = date.toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' });
    const dateStr = date.toLocaleDateString('pt-PT');

    return (
        <View style={[styles.eventCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={styles.eventIcon}>
                <Text style={styles.eventIconText}>⚠️</Text>
            </View>
            <View style={styles.eventDetails}>
                <Text style={[styles.eventTime, { color: colors.text }]}>{timeStr}</Text>
                <Text style={[styles.eventDate, { color: colors.inactive }]}>{dateStr}</Text>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    scrollContent: {
        padding: 20,
    },
    title: {
        fontSize: 28,
        fontWeight: 'bold',
        marginBottom: 20,
    },
    emptyState: {
        alignItems: 'center',
        paddingVertical: 60,
    },
    emptyIcon: {
        fontSize: 80,
        marginBottom: 20,
    },
    emptyText: {
        fontSize: 18,
        marginBottom: 10,
    },
    emptySubtext: {
        fontSize: 14,
        textAlign: 'center',
    },
    statsCard: {
        borderRadius: 16,
        padding: 20,
        marginBottom: 20,
        borderWidth: 1,
    },
    statsTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        marginBottom: 15,
    },
    statsRow: {
        flexDirection: 'row',
        justifyContent: 'space-around',
    },
    statItem: {
        alignItems: 'center',
    },
    statValue: {
        fontSize: 28,
        fontWeight: 'bold',
        color: '#2196F3',
        marginBottom: 5,
    },
    statLabel: {
        fontSize: 12,
        textAlign: 'center',
    },
    chartCard: {
        borderRadius: 16,
        padding: 20,
        marginBottom: 20,
        borderWidth: 1,
    },
    chartTitle: {
        fontSize: 16,
        fontWeight: 'bold',
        marginBottom: 15,
    },
    chart: {
        marginVertical: 8,
        borderRadius: 16,
    },
    listTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        marginBottom: 15,
        marginTop: 10,
    },
    eventCard: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 15,
        borderRadius: 12,
        marginBottom: 10,
        borderWidth: 1,
    },
    eventIcon: {
        width: 50,
        height: 50,
        borderRadius: 25,
        backgroundColor: '#FF3B30',
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: 15,
    },
    eventIconText: {
        fontSize: 24,
    },
    eventDetails: {
        flex: 1,
    },
    eventTime: {
        fontSize: 16,
        fontWeight: 'bold',
        marginBottom: 3,
    },
    eventDate: {
        fontSize: 13,
    },
});
