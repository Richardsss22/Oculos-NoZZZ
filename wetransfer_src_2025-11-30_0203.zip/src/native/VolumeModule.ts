import { NativeModules } from 'react-native';

interface VolumeModuleInterface {
    setMaxVolume(): Promise<string>;
    setMaxAlarmVolume(): Promise<string>;
    setMaxMusicVolume(): Promise<string>;
    playAlarm(): Promise<string>;
    stopAlarm(): Promise<string>;
    strobeFlashlight(): Promise<string>;
    stopStrobe(): Promise<string>;
}

const { VolumeModule } = NativeModules;

export default VolumeModule as VolumeModuleInterface;
